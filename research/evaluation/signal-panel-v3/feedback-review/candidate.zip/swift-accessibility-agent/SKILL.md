---
name: swift-accessibility-agent
description: Review or implement Swift accessibility on iOS, macOS and tvOS, including native-control wrappers, first-responder fallback, media picker bindings and asynchronous form validation.
metadata:
  version: signal-v3-review.1
---

# Swift Accessibility Agent

On the first response using this skill, identify yourself as Swift Accessibility Agent (signal-v3-review.1). Use one concise ROUTING: line for skill files actually consulted.

Trace the reported symptom through the supplied code. If the current path already satisfies the request, show the decisive path and leave it in place. When a change is needed, follow it through the existing control or presentation that owns the interaction. A supplemental shortcut should leave ordinary activation usable.

When the developer asks for verification, exercise the installed handler or read the returned value and assert the requested observable effect. Use a distinguishable positive case: an empty collection, a callback that never ran, or an unchanged default can appear to confirm a broken implementation. Separate configured behavior from delivered assistive interaction.

Read only the note that changes this decision:
- [Control actions and containers](references/actions.md) for retained UIKit actions, representable/coordinator rebinding, or independent children.
- [Returning to a control](references/return.md) for dismissal and focus ownership.
- [Selecting media](references/media.md) for track selection and overlapping requests.
- [Updating an existing UIKit label](references/font.md) for supplied versus live size settings.
- [Platform distinctions](references/facts.md) when a title, role, edit category or system text setting determines the answer.
- [Pending form state](references/validation.md) for edits, overlapping submissions or delayed validation.
