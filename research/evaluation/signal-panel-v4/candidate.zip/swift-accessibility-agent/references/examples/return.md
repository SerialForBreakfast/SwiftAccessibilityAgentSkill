Per-presentation SwiftUI modifier

```swift
import SwiftUI

@MainActor final class SheetOwner {
    private var active: UUID?
    private let restore: (String) -> Void
    init(restore: @escaping (String) -> Void) { self.restore = restore }

    func presentation(origin: String, showing: Binding<Bool>) -> OwnedSheet {
        let id = UUID()
        active = id
        return OwnedSheet(showing: showing) { [weak self] in
            guard let self, self.active == id else { return }
            self.active = nil
            self.restore(origin)
        }
    }
}

// Keep this modifier with its presentation instance, not in shared mutable callback storage.
struct OwnedSheet: ViewModifier {
    let showing: Binding<Bool>
    let onDismiss: () -> Void
    func body(content: Content) -> some View {
        content.sheet(isPresented: showing, onDismiss: onDismiss) { Text("Editor") }
    }
}
```

UIKit teardown and snapshot release (methods on RestoringPanel)

```swift
    private func finish(notify: Bool) {
        let target = returnTarget.flatMap { candidate -> UIView? in
            guard let background, !priorHidden, candidate.isDescendant(of: background) else { return nil }
            return candidate
        }
        background?.accessibilityElementsHidden = priorHidden
        background = nil
        returnTarget = nil
        state = .closed
        isHidden = true
        accessibilityElementsHidden = true
        accessibilityViewIsModal = false
        onPrimary = {}
        if notify { post(.screenChanged, target) }
    }

    /// Owner calls before discarding the panel, even if dismissal has not completed.
    func tearDown() {
        guard state != .closed else { return }
        generation += 1
        finish(notify: false)
    }

    override func accessibilityPerformEscape() -> Bool { dismiss() }
```
