Installed shortcut (inside configure)

```swift
        let shortcut = action(view, secondary: true)
        view.primary.accessibilityCustomActions = [UIAccessibilityCustomAction(name: "Details \(snapshot.title)") { _ in shortcut() }]
```

Captured registration (method on SurfaceOwner)

```swift
    func action(_ view: NativeSurface, secondary: Bool) -> () -> Bool {
        let ticket = generation
        return { [weak self, weak view] in
            guard let self, let view, self.surface === view, self.generation == ticket,
                  self.snapshot.enabled, (secondary ? view.details : view.primary).isEnabled else { return false }
            self.perform(self.snapshot.id, secondary); return true
        }
    }
```
