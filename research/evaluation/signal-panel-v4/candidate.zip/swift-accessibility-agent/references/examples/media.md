Binding captures the load (property on MediaSelectionStore)

```swift
    var selection: Binding<String?> {
        let ticket = generation, owningItem = item
        return Binding(get: {
            guard self.generation == ticket, self.item === owningItem else { return nil }
            return self.selectedID
        }, set: { id in
            guard self.generation == ticket, self.item === owningItem else { return }
            _ = self.choose(id)
        })
    }
```

Write to the current player item (method on the same store)

```swift
    @discardableResult
    func choose(_ id: String?) -> Bool {
        guard isCurrent, let group, let item else { return false }
        if let id {
            if id == unlistedSelectionID, unlistedSelectionName != nil { return true }
            guard let choice = choices.first(where: { $0.id == id }) else { return false }
            item.select(choice.option, in: group)
        } else {
            guard allowsOff else { return false }
            item.select(nil, in: group)
        }
        selectionRevision += 1
        return true
    }
```
