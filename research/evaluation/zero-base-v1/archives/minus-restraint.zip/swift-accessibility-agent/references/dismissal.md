# Closing a presentation and returning focus

Record the opener for this presentation. Requesting dismissal does not finish it. At the owning completion (for example SwiftUI's onDismiss), consume that presentation's pending restoration before calling outward. Ignore superseded callbacks. Resolve the current eligible opener, then a valid fallback; if neither exists, make no request. On tvOS a request is not evidence of delivered focus.
