# Shortcuts and independently usable controls

Trace each ordinary action before adding a shortcut. UIKit: preserve the existing controls and their enabled-state checks when adding a custom action. On Apple TV, keep Select connected to the current item. In SwiftUI, put an alternative on the existing action path rather than firing both handlers. Before proposing a keyboard alternative, check the command API on the actual OS: sharing SwiftUI does not make a Mac command available on other targets. A rotor or shortcut can save steps without becoming the only way to finish the task.
