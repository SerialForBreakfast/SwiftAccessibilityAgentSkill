# Inspecting media or applying a delayed result

At delivery, compare the requested item with the player's actual current item, not just the last item the view cached. Track request ownership too when a newer request can supersede one on the same item. An inspection reports available options and current selection separately; it does not select a track. Keep an unfinished load, an error and a successful empty result distinguishable.
