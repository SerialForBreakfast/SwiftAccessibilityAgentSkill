# Testing delayed or repeated callbacks

Build the test around the event that can go wrong. Wait for a deterministic registration signal before delivering a delayed response. To test duplicate callback delivery, use a boundary that can deliver twice, not a continuation that may resume only once. Exercise the live owner and assert the effect on the existing control or state; invoking a helper alone establishes less.
