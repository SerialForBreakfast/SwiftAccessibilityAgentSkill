# Updating text in an existing checkout or form

Follow a long localized value through font configuration, line wrapping and the enclosing layout. If a later callback changes the row, show how it reaches the same installed views; a variable local to setup is not available in a separate method. Flexible layouts can remain vertical or adapt. Preserve the original payment control, its appearance and its action.
