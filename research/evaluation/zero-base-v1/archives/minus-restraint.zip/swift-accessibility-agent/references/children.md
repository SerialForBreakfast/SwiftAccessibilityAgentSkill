# AppKit containers and hosted controls

On Mac, examine the parent role together with the children it exposes. A descriptive group and an actionable leaf are different designs. Keep independent buttons and their target/action paths intact. At an NSHostingView boundary, identify whether AppKit or SwiftUI creates the interactive child before changing the parent. If the supplied code ends at that boundary, give conditional advice.
