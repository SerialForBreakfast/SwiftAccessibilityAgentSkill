# UIKit font scaling for a supplied or live text setting

Decide whose text-size setting the label must follow. For a caller-selected size, scale the unscaled design font against the supplied traits and preserve that result; automatic tracking of the label's own environment can override it. For live changes, use environment tracking or rescale from the original font on changes. Check the typeface and effective size, not just a tracking flag.
