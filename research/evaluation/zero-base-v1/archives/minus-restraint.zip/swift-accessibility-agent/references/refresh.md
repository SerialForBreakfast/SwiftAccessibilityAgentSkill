# Reconfiguring a live row or card

Walk through A then B on the same instance, including B with missing optional text. Replace or clear the fields this configuration owns on every update, not only on reuse. A rename-only update leaves unrelated fields alone. A permanently connected action can resolve the current owner at activation; a per-binding callback must not outlive that binding.
