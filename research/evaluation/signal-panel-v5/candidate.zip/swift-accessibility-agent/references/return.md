A close request, cancellation and completed dismissal are different events. Keep the origin independently of the presented content. Complete only the owning dismissal, consume its return request before calling reentrant code, and resolve the destination against what is eligible then.

For a sheet, take the ordinary Close path before completing it. Contrast an origin that survives with one that disappears. Capture the owner when each presentation opens, not from shared state at dismissal. Exercise the installed closures: finish A late, then B twice; only B may restore, once. Serialize only if the product requires it. Passing a known ticket to a helper does not exercise an installed callback that reads the current ticket.

For overlapping UIKit panels, restore or transfer the original background snapshot before the next panel captures it. Finish the replacement too: suppression while it is open says nothing about the final state. Preserve an initially hidden background and the panel's ordinary controls.

For AppKit, check ownership by the originating window. An absent origin and an attached one that declines first-responder eligibility can both require fallback; removing a button only checks the first. Where fallback is required, try it both when the origin is ineligible and when the eligible origin rejects the request. A detached-origin test covers neither attached case. Report requests, not delivered assistive focus.

[Implementation excerpts](examples/return.md)
