# Form validation, late replies and restarted observers

- Compare the submitted values with the editable control at delivery. Editing through a helper that cancels the request cannot demonstrate what happens when a native field changes directly.

- A superseded completion must not release the replacement's busy state. A cancellation for the still-current operation, by contrast, must leave the user able to try again.

- Mark a submission consumed before calling client code. If client code immediately submits again, the old completion must leave that request intact.

- Apply errors to the live field they describe. On recovery remove the obsolete message from that field while retaining unrelated errors and input.

- Unregistering stops future registration deliveries, not necessarily work already queued. After restart, deliver an old notification and a new one and distinguish their effects.

