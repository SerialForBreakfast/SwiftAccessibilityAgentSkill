# Motion preferences and color contrast

- Reduce Motion changes how an update is presented, not whether it happens. Inspect the new content and selected value as well as the motion policy.

- Distinguish an immediate update from a shortened animation when the product requires no transition. If the existing effective preference already selects the right branch, preserve it.

- For sRGB luminance, a midtone distinguishes linearized light from encoded channel values; black and white alone cannot detect a missing transfer step.

- For translucent content, establish the actual background before calculating a rendered ratio. If the calculator accepts only opaque samples, report that boundary.

- Resolve semantic colors in the requested appearance before comparing them. One light-mode pair cannot verify the dark-mode decision.

