# Reused controls, shortcuts, registration and edit authority

- A registration belongs to a particular binding, not just a model ID. A new binding may reuse the same key. Exercise a retained action across rebinding and compare its recipient with the newly installed action's.

- A moved button can still have a parent. Decide whether the component still owns that button before delivering its command; attachment by itself answers a different question.

- An action retained while enabled can outlive permission to perform it. Read eligibility at dispatch; restoring permission should restore ordinary operation.

- Try the actual buttons independently. A passing keyboard or accessibility shortcut tells you nothing about whether the ordinary button dispatched Open, Save, Details or Play.

- For a representable, distinguish make, update and dismantle. Refresh registrations on the object that owns them; tearing down an obsolete coordinator must not unplug its replacement.

- A plausible action title does not establish its destination. Follow the named installed action through to its return value and recipient.

- While the command remains retained, change the editor to read-only and invoke it. Opening a menu is not the event that revokes editability.

