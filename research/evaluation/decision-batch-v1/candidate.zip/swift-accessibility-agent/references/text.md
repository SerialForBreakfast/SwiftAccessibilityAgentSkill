# Rotor search, text coordinates and scaling

- Carry the producing API's coordinate system and document identity to the consuming API. Recover the actual substring; comparing two integers can agree even when they point at the wrong text.

- An edit can leave a cached match in bounds but no longer matching. Resolve against the current document before moving the cursor.

- Use the current target and navigation direction rather than selecting the first match on every request. Keep ordinary heading traversal usable after a reorder.

- For intersecting matches, ask whether the product advances from the start or end of the last match. Both policies can be correct; a repeated-pattern input distinguishes them.

- Follow the actual source of text size: a caller-supplied preview setting and the live environment are different inputs. Exercise a second size on the same view and retain its action.

- Recompute a scaled font from its design size, not the previous scaled output. A round trip between two sizes exposes compounding.

