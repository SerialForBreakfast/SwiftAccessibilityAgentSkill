# Dismissal, background exposure and focus restoration

- Separate asking to close from completing the transition. A refusal leaves the presentation active; an accepted but unfinished dismissal has not yet earned a restoration request.

- Capture the presentation at callback installation. Reading a shared current ticket inside a late callback gives the retired presentation the replacement's authority.

- Consume the outgoing presentation before the external restoration call. That call can synchronously open another presentation; cleanup afterward can erase it.

- Choose the destination when restoration is due. On Mac, distinguish being visible from accepting first responder; try the eligible fallback if the original refuses.

- Restore the owner's saved background configuration. Unconditionally setting a flag to false can expose content that was hidden even before the panel opened.

