# Containers, native controls, row semantics and visible names

- Identify the interactive owner before grouping. A shelf or wrapper may organize navigation while each episode still owns its own activation.

- For an AppKit row, inspect role, selection and independently usable children separately. A correctly titled row does not prove any of those three properties.

- Preserve surviving selection across sibling moves by identity. Duplicate display titles distinguish identity from accidental reselection by name or position.

- Resolve interior coordinates of a spanning cell as well as its origin. Treat coordinates outside the grid separately from valid covered positions.

- Change only the trait bits owned by this state transition. Start with unrelated traits present and toggle both ways; replacing the entire set can pass an initially empty fixture.

- Decide which audience is missing a name: sighted users, assistive clients or test automation. Inspect the displayed title if the complaint concerns what people see.

- Reset decoration on reconfiguration without hiding the whole row. Begin with the decoration exposed so an omitted reset is observable.

- An empty help string and an absent value are not interchangeable when the configuration contract distinguishes them. Rebind the same control without help; its ordinary action must survive.

- Two empty strings can agree while conveying no state. Compare visible and accessibility status against the intended meaning in each selection state.

- Select an editing category only for actions that represent editing. Leave the default alone for ordinary commands and verify the declared SDK member rather than guessing its spelling.

- In SwiftUI hosting AppKit, hide redundant chrome only if the native search field and its Clear path remain independently usable. Hiding the entire wrapper is not evidence that the editor survives.

- A labeled native slider with a working binding is a preservation case unless the input identifies a concrete unmet requirement. The absence of a custom value modifier is not a defect or a prediction of speech.

