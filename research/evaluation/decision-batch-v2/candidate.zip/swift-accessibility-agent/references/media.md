# Player item selection, metadata and asynchronous menus

- Follow a picker write past the menu state into the selected option on the same player item. Changing an app-side ID alone can leave playback untouched.

- Before offering a clear operation check whether the group permits an empty choice. A rejected clear leaves both the player and its displayed choice unchanged.

- Filtering the menu can hide the currently selected option. Preserve that state distinctly from no selected option; rebuilding the menu is not a user command.

- A clear callback is still a write. Retain the setter, replace the player item, then invoke it: the replacement keeps its choice while its own current setter remains usable.

- Two loads can race on the very same item. Item identity filters replacement items but cannot order requests for one item; accept only the current request's result.

- Separate not loaded, load failed and successfully inspected with zero options. Report the observed state rather than inventing an empty menu; allow recovery from a failed load.

- Use an authored local movie, not a fabricated AVMediaSelectionGroup. Load the .legible group from the AVPlayerItem's asset with loadMediaSelectionGroup(for:). Identify candidates by language and hasMediaCharacteristic(.containsOnlyForcedSubtitles); for a full-caption policy reject forced-only choices. Drive the production choice, then read item.currentMediaSelection.selectedMediaOption(in: group); check the full option itself and preserve the audible selection. To catch a missing filter specifically, establish that the first language match is forced and a full match follows; if the asset lists full first, pass its real options in both orders through the production chooser or use another authored asset. A reordered helper alone does not prove the picker calls it.

- On each audible option use hasMediaCharacteristic(.describesVideoForAccessibility). Language, transcription, or simply being alternate audio does not identify a description. Compare inspection of tagged and untagged assets with the same language layout and check the mapped option, not just the count. Inspection must not write a selection.

- Keep buffer observations and player readiness as separate facts. They may disagree; do not convert either into a guarantee that playing now will succeed.

- Returning control to automatic selection can choose another track. If the request is Off, distinguish an explicitly empty selection from system choice and inspect the item's resulting option.

- Repeated selection of the active speed is not a new transition. Drive the actual selection binding twice, count effects, then change speed and confirm one real update still passes through.


- On request: [local positive movie](../fixtures/positive.mov)
- On request: [local control movie](../fixtures/control.mov)
Use these silent assets for metadata and selection, not narration quality.
