# Reused controls, shortcuts, registration and edit authority

- Compose lifetime and permission checks; do not replace one with the other. A retained handler must belong to this registration AND still be allowed to act. Capture a per-binding generation or lease when installing Delete. Looking up today's item by key or comparing equal values can delete its indistinguishable replacement. Deliver the retired handler across an equal-value rebind, then exercise the current ordinary action.

- A moved button can still have a parent. Decide whether the component still owns that button before delivering its command; attachment by itself answers a different question.

- Exercise the installed command on its current, attached but disabled button. It must not dispatch; re-enable that very button and exercise primary activation. Testing only an absent identifier can pass because a downstream lookup already ignores it.

- Try the actual buttons independently. A passing keyboard or accessibility shortcut tells you nothing about whether the ordinary button dispatched Open, Save, Details or Play.

- For a representable, distinguish make, update and dismantle. Refresh registrations on the object that owns them; tearing down an obsolete coordinator must not unplug its replacement.

- A plausible action title does not establish its destination. Follow the named installed action through to its return value and recipient.

- While the command remains retained, change the editor to read-only and invoke it. Opening a menu is not the event that revokes editability.

