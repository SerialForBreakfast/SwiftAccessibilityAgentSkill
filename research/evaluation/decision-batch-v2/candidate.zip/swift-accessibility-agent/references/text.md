# Rotor search, text coordinates and scaling

- For a literal NSString search displayed unchanged in UITextView, NSRange.location and length are UTF-16 distances. Form start and exclusive end from beginningOfDocument using location and NSMaxRange respectively, checking optional positions and range. Neither add an extra unit nor substitute Swift Character or glyph counts. With emoji and combining marks before the match, read the selected substring from the same live text view.

- An edit can leave a cached match in bounds but no longer matching. Resolve against the current document before moving the cursor.

- Use the current target and navigation direction rather than selecting the first match on every request. Keep ordinary heading traversal usable after a reorder.

- For intersecting matches, ask whether the product advances from the start or end of the last match. Both policies can be correct; a repeated-pattern input distinguishes them.

- Follow the actual source of text size: a caller-supplied preview setting and the live environment are different inputs. Exercise a second size on the same view and retain its action.

- Recompute a scaled font from its design size, not the previous scaled output. A round trip between two sizes exposes compounding.

