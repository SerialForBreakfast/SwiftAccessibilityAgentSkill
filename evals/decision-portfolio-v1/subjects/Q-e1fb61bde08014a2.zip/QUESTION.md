tvOS 26 / SwiftUI

A long localized episode title leaves little space for Play and Details on our Apple TV screen. What layout would you ship for tvOS 26, and what would you change only on a later supported release?

Project requirements:
tvOS, SwiftUI. Product wants titles readable from a couch. A long German title in our tvOS SwiftUI detail header crowds out Play and Details. What would you change on a 26.0 deployment target, and what would you condition on a newer SDK?
