iOS 26 / SwiftUI

If someone switches Reduce Motion while reading page two, what happens on the next page change? Keep the current page and explain any change the supplied implementation needs. There are no other animations or parent transactions.

Supplied source:

```swift
import SwiftUI

enum PageMotionPolicy {
    static func shouldAnimate(reduceMotion: Bool) -> Bool {
        !reduceMotion
    }
}

struct PageView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var page = 0
    private let pages = ["Account", "Playback", "Downloads"]

    var body: some View {
        VStack {
            Text(pages[page])
                .id(page)
                .transition(.slide)
            Button("Next page") {
                page = (page + 1) % pages.count
            }
        }
        .animation(
            PageMotionPolicy.shouldAnimate(reduceMotion: reduceMotion)
                ? .easeInOut(duration: 0.2) : nil,
            value: page
        )
    }
}
```
