tvOS 26 / SwiftUI

The video hasn't changed, but the user reloaded caption choices. Can a retained Off callback from the previous list still clear their current choice? Implement the ownership check on the installed picker and test the current choice too.

Supplied source:

```swift
import SwiftUI
import Observation
import AVKit

struct CaptionOption: Identifiable {
    let id: String
    let name: String
}

@MainActor @Observable
final class CaptionState {
    let player: AVPlayer
    var options: [CaptionOption] = []
    var selected: String?
    var loading = false
    init(player: AVPlayer) { self.player = player }
    func load(using loader: (@escaping @MainActor ([CaptionOption]) -> Void) -> Void) {
        loading = true
        loader { options in self.options = options; self.loading = false }
    }
    func choose(_ id: String?) { selected = id }
}

struct CaptionScreen: View {
    @Bindable var state: CaptionState
    var body: some View {
        VStack {
            VideoPlayer(player: state.player)
            Picker("Captions", selection: Binding(get: { state.selected }, set: { state.choose($0) })) {
                Text("Off").tag(nil as String?)
                ForEach(state.options) { option in Text(option.name).tag(Optional(option.id)) }
            }
        }
    }
}
```
