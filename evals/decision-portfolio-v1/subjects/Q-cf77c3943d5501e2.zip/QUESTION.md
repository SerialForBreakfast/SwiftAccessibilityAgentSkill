iOS 26 / SwiftUI

Does anything in this notification preference stop a user from reading and changing the setting? Show only changes this screen needs; the store owns persistence.

Supplied source:

```swift
struct NotificationSettings: View {
    @Binding var notificationsEnabled: Bool
    var body: some View {
        Form {
            Toggle("Notifications", isOn: $notificationsEnabled)
        }
    }
}
```
