macOS 26 / AppKit

Our NSStackView invoice row is configured again for another invoice. How would you keep Open and Save separately usable and let Open offer Save as an optional shortcut? Callers supply localized names; disabled Save must not fire. Show the code and describe a check.

Project requirements:
Our AppKit invoice list reuses an NSStackView row containing a title, Open button and Save button. Implement a programmatic row that can be configured repeatedly with a new title, complete localized control names and callbacks. Keep both buttons independently usable, and offer Save as an optional accessibility action on Open. Disabled Save must not dispatch. What would you implement, and what can unit tests establish?
