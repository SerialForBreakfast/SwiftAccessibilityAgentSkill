macOS 26 / AppKit

Two document windows have inspectors. While the first inspector is open, its former editor can move to the other window. Where should keyboard input go on close, and who owns that decision?

Project requirements:
macOS, AppKit. Two document windows can each open their own inspector. Closing the inspector in one window sometimes sends keyboard input to the other document. How would you structure ownership of the return destination?
