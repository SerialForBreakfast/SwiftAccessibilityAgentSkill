macOS 26 / AppKit

Our AppKit library outline has Name and Kind columns. Implement updates by stable ID so rename, reorder and removal preserve surviving expansion and selection. How will your tests handle a retained removed node and duplicates anywhere in an update?

Project requirements:
We use a programmatic AppKit NSOutlineView for a nested library. Entries have stable IDs, titles and child arrays. Show Name and Kind columns. Updates can rename, reorder or remove entries; keep surviving item identity, expansion and visible selection where possible. Reject duplicate IDs anywhere in an update without partly changing the current tree. Removed entries should not continue supplying stale child data. Implement the data source for macOS 26 and unit tests; do not drive the UI.
