// swift-tools-version: 5.9
import PackageDescription
let package = Package(name:"Feature", platforms:[.macOS("26.0"),.iOS("26.0")], products:[.library(name:"Feature",targets:["Feature"])], targets:[.target(name:"Feature"),.testTarget(name:"Checks",dependencies:["Feature"])])
