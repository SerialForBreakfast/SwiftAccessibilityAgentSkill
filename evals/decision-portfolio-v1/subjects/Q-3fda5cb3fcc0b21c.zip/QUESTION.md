tvOS 26 / UIKit

If a tvOS viewer asks for described audio in a language with only an ordinary track, what happens to the track already playing? Show how to check that behavior and change only what is necessary. If it already meets the requirement, leave it intact; otherwise include the smallest integrated change and a focused unit check.

Supplied source:

```swift
import AVFoundation

@MainActor
public enum MediaChoice {

    @discardableResult
    public static func select(language: String, requiresDescription: Bool = false,
                              in group: AVMediaSelectionGroup, item: AVPlayerItem) -> Bool {
        guard let option = group.options.first(where: {
            $0.locale?.language.languageCode?.identifier == language &&
            !$0.hasMediaCharacteristic(.containsOnlyForcedSubtitles) &&
            true
        }) else { return false }
        item.select(option, in: group)
        return true
    }
    @discardableResult
    public static func turnOff(in group: AVMediaSelectionGroup, item: AVPlayerItem) -> Bool {
        return requestOff(allowed: group.allowsEmptySelection) { item.select(nil, in: group) }
    }

    static func requestOff(allowed: Bool, clear: () -> Void) -> Bool {
        guard allowed else { return false }
        clear()
        return true
    }
}
```
