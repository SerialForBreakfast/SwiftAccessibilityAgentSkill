iOS 26 / UIKit

The same download can report completion twice; callbacks from a previous download can arrive late. Keep progress readable, clamp it to 0 through 100, and announce completion once per current ID. What would you ship?

Supplied source:

```swift
import UIKit

enum DownloadUpdate {
    case progress(Int)
    case completed
    case failed(String)
}

final class DownloadStatus {
    let label: UILabel
    private var activeID: UUID?

    init(label: UILabel) {
        self.label = label
        label.isAccessibilityElement = true
        label.accessibilityLabel = "Download"
    }

    func begin(id: UUID) {
        activeID = id
        label.text = "0%"
        label.accessibilityValue = "0%"
    }

    func receive(id: UUID, update: DownloadUpdate) {
        let text: String
        switch update {
        case .progress(let value): text = "\(value)%"
        case .completed: text = "Download complete"
        case .failed(let reason): text = "Download failed: \(reason)"
        }
        label.text = text
        label.accessibilityValue = text
        UIAccessibility.post(notification: .announcement, argument: text)
    }
}
```
