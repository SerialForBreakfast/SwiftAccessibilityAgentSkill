iOS 26 / SwiftUI

Our settings owner persists this volume binding. Does this slider need a change to support adjustment from 0 to 100 in single steps? Explain what you would ship.

Supplied source:

```swift
import SwiftUI

struct VolumeSettings: View {
    @Binding var volume: Double

    var body: some View {
        Form {
            Slider(value: $volume, in: 0...100, step: 1) {
                Text("Volume")
            }
        }
    }
}
```
