iOS 26 / UIKit

I use the same invoice card for two customers in succession. Can you implement its configuration and test what the two buttons say and which customer's handlers run? The star is decoration; the caller supplies localized names.

Project requirements:
I'm building reusable UIKit cards for invoices, supporting iOS 26 and later. Each card shows a decorative star, an invoice title, and separate Open and Save buttons. Every card has the same visible button titles. The same card instance can be configured for another invoice without being removed. Can you show the Swift configuration and unit tests so someone can tell which invoice each button acts on, while both buttons still work normally? Our callers can supply localized strings and the two operation handlers. Focus on configuration and behavior, not layout. Explain what the unit tests establish.
