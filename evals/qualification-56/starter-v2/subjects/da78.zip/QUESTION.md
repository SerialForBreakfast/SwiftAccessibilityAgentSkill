macOS 26.0, SwiftUI. Sheet A starts closing, then this view presents B. A delayed dismissal from A arrives. Can it change focus or close B?

Explain your conclusion and give a focused check. Include integrated Swift changes if the requested behavior needs them.


Use the callbacks on the registrations actually installed by the host: deliver an earlier dismissal after a replacement opens, then deliver the replacement dismissal twice. The complete starter is in Sources/Starter. Put your focused unit checks in Tests/Checks.
