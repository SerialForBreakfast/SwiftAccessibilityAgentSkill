# iOS developer question

My SwiftUI video screen only changes a local selected value when someone chooses captions. Connect the choices to the real media item without resetting audio or playback settings. Offer complete captions rather than tracks with just occasional translated lines. Preserve a current choice outside that list without pretending it is Off. Include focused unit tests. Target iOS26 or later. 

Use the supplied local CaptionFixture instead of remote URLs. Open independent items with selected: .ordinary or .forced. Inspect the item’s native legible and audible selections before and after the interaction. The complete starter is in Sources/Starter. Put your focused unit checks in Tests/Checks.
