# macOS developer question

People can change videos or reload caption choices while this SwiftUI screen is open. Old callbacks sometimes affect the new selection, including turning captions off. Make these operations belong to the right item and request, and include focused unit tests. Explain how the screen should react when the player item changes and what cancellation does. Target macOS26 or later. 

Use the supplied local CaptionFixture instead of remote URLs. Open independent items with selected: .ordinary or .forced. Inspect the item’s native legible and audible selections before and after the interaction. The complete starter is in Sources/Starter. Put your focused unit checks in Tests/Checks.
