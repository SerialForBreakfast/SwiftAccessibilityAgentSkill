// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "Starter", platforms: [.macOS("26.0"), .iOS("26.0"), .tvOS("26.0")],
    products: [.library(name: "Starter", targets: ["Starter"])],
    targets: [.target(name: "Starter", resources: [.copy("Captions.mov")]), .testTarget(name: "Checks", dependencies: ["Starter"])])
