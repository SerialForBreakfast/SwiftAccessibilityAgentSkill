# iOS developer question

Build a SwiftUI media-option picker using the same player as the video view. It should show the real selection, distinguish loading, absent options and failure, and allow retry. Keep normal player controls. Include focused unit tests and state which external changes require an explicit reload. Target iOS26 or later. 

Use the supplied local CaptionFixture instead of remote URLs. Open independent items with selected: .ordinary or .forced. Inspect the item’s native legible and audible selections before and after the interaction. The complete starter is in Sources/Starter. Put your focused unit checks in Tests/Checks.
