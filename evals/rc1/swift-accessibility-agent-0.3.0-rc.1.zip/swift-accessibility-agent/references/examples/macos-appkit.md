# AppKit: ordinary actions and status notifications

Deployment 26.0; recorded platform family macOS, runtime major 27. Source revision 2, SHA-256 1cd99e299d978005951ffce544e3644ca471e0d413ffa67d6febccaf3080c39e.

Unit configuration, callbacks, preferred candidates and notification requests only. No UI tests, actual assistive technology navigation, visual layout or usability claims. macOS host27 does not establish macOS26 runtime behavior.

- [Custom action handlers and explicit accessible metadata; ordinary action/reuse rules are application policy](https://developer.apple.com/documentation/appkit/nsaccessibilitycustomaction)

```swift
import AppKit

@MainActor
final class DesktopActions: NSStackView {
    let title = NSTextField(labelWithString: "")
    let open = NSButton(title: "Open", target: nil, action: nil)
    let save = NSButton(title: "Save", target: nil, action: nil)
    private var generation = 0
    private var onOpen: () -> Void = {}
    private var onSave: () -> Void = {}

    init() {
        super.init(frame: .zero)
        [title, open, save].forEach { addArrangedSubview($0) }
        open.target = self; open.action = #selector(openItem)
        save.target = self; save.action = #selector(saveItem)
    }
    required init?(coder: NSCoder) { fatalError("Programmatic example") }

    func configure(title text: String, openName: String, saveName: String,
                   onOpen: @escaping () -> Void, onSave: @escaping () -> Void) {
        generation += 1
        let revision = generation
        self.onOpen = onOpen; self.onSave = onSave
        title.stringValue = text
        setAccessibilityElement(false)
        title.setAccessibilityElement(true)
        open.setAccessibilityElement(true); save.setAccessibilityElement(true)
        open.setAccessibilityLabel(openName); save.setAccessibilityLabel(saveName)
        open.setAccessibilityValue(nil); save.setAccessibilityValue(nil)
        // An optional shortcut supplements, rather than replaces, the ordinary Save button.
        open.setAccessibilityCustomActions([NSAccessibilityCustomAction(name: saveName) { [weak self] in
            guard let self, self.generation == revision, self.save.isEnabled else { return false }
            self.onSave()
            return true
        }])
    }
    @objc private func openItem() { guard open.isEnabled else { return }; onOpen() }
    @objc private func saveItem() { guard save.isEnabled else { return }; onSave() }
}

@MainActor
final class DesktopStatus {
    let label = NSTextField(labelWithString: "")
    private let post: (Any, NSAccessibility.Notification) -> Void
    init(post: @escaping (Any, NSAccessibility.Notification) -> Void = {
        NSAccessibility.post(element: $0, notification: $1)
    }) { self.post = post }
    func update(_ value: String) {
        guard value != label.stringValue else { return }
        label.stringValue = value
        post(label, .valueChanged)
    }
}
```
