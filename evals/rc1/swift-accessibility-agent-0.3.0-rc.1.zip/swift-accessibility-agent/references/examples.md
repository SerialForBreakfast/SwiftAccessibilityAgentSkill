# Examples on demand

Read one card for the target and task. These are companion examples, not prescriptions for a particular architecture.

- [iOS UIKit: reusable choice labels](examples/ios-uikit.md)
- [iOS SwiftUI: native controls and adjustable state](examples/ios-swiftui.md)
- [AppKit: ordinary actions and status notifications](examples/macos-appkit.md)
- [macOS SwiftUI: preferences and layout](examples/macos-swiftui.md)
- [tvOS UIKit: ordinary actions and focus candidates](examples/tvos-uikit.md)
- [tvOS SwiftUI: list identity and rotor landmarks](examples/tvos-swiftui.md)
