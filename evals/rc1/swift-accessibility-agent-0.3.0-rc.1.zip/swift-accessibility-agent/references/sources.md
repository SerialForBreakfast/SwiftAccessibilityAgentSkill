# Apple sources and scoped declarations

## iOS UIKit: reusable choice labels
- [UILabel.h numberOfLines, lineBreakMode, adjustsFontSizeToFitWidth](https://developer.apple.com/documentation/uikit/uilabel/numberoflines)
- [UIFont.h preferredFontForTextStyle:compatibleWithTraitCollection:; UIContentSizeCategoryAdjusting.h](https://developer.apple.com/documentation/uikit/uifont/preferredfont(forTextStyle:compatibleWith:))
- [UIAccessibilityConstants.h selected trait; UIAccessibility.h value; UITableViewCell.h accessoryType](https://developer.apple.com/documentation/uikit/uiaccessibilitytraits/selected)
- [UITableView.h rowHeight/estimatedRowHeight/automaticDimension; UIView.h anchors](https://developer.apple.com/documentation/uikit/uitableview/automaticdimension)

## iOS SwiftUI: native controls and adjustable state
- [Public SwiftUI API composition; exact installed SDK declarations and narrow application contract](https://developer.apple.com/documentation/swiftui/view-accessibility)

## AppKit: ordinary actions and status notifications
- [Custom action handlers and explicit accessible metadata; ordinary action/reuse rules are application policy](https://developer.apple.com/documentation/appkit/nsaccessibilitycustomaction)

## macOS SwiftUI: preferences and layout
- [Public SwiftUI API composition; exact installed SDK declarations and narrow application contract](https://developer.apple.com/documentation/swiftui/scaledmetric)

## tvOS UIKit: ordinary actions and focus candidates
- [Custom action handlers and explicit accessible metadata; ordinary action/reuse rules are application policy](https://developer.apple.com/documentation/uikit/uiaccessibilitycustomaction)

## tvOS SwiftUI: list identity and rotor landmarks
- [Public SwiftUI API composition; exact installed SDK declarations and narrow application contract](https://developer.apple.com/documentation/swiftui/view/accessibilityrotor(_:entries:entrylabel:))

- [macos-focus-requests](sdk/macos-focus-requests.md)
- [macos-text-sizing](sdk/macos-text-sizing.md)
- [macos-values](sdk/macos-values.md)
- [tvos-actions](sdk/tvos-actions.md)
- [tvos-children](sdk/tvos-children.md)
