tvOS 26 / SwiftUI

A transcript search has overlapping matches. A user who does not use the rotor still needs ordinary previous and next controls. What should own each piece of state, and what should the developer preserve when the screen updates? Give a bounded implementation plan; call out anything the description does not establish.
