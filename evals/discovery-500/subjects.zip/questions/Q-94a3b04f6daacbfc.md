iOS 26 / UIKit

The background was already inaccessible for an unrelated reason before this panel opened. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -108,9 +108,9 @@
         guard isOpen && canDismiss else { return false }
         isOpen = false
         isHidden = true
         accessibilityElementsHidden = true
-        accessibilityViewIsModal = false
+        accessibilityViewIsModal = true
         onDismiss()
         return true
     }
 
```
