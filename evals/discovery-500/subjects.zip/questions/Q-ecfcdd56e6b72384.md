iOS 26 / SwiftUI

Support reported this interaction, but we do not have a recording. Give two plausible explanations, a sequence that distinguishes them, and what you could conclude from each result.

Background from the original feature request (answer the question above):
I am using SwiftUI on iOS 26 deployment target; available validation anchor iOS 26.5.

A video card can show whether audio description is available. Loading track information may succeed with no match, fail, or still be in progress. The player item can change before loading finishes. We must preserve the user’s selected audio and captions. How should the metadata state and callback logic work, and what would unit tests prove?

This is a design/debugging question; no existing project or omitted source files are available. If code is useful, supply a self-contained minimal example and state material assumptions. Do not execute anything.
