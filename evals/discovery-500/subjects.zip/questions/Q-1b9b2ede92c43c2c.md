iOS 26 / UIKit

A native text field changes before validation returns, without going through the form's edit helper. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -31,9 +31,9 @@
         let ticket = generation, input = snapshot
         active = ticket; busy = true; errors = [:]; status.text = "Checking"
         validate(input) { [weak self] result in
             guard let self, self.active == ticket else { return }
-
+            guard self.snapshot == input else { self.cancel(); return }
 
             self.active = nil; self.busy = false
             guard result.keys.allSatisfy({ self.fields[$0] != nil }), result.values.allSatisfy({ !$0.isEmpty }) else {
                 self.status.text = "Validation unavailable"; return
```
