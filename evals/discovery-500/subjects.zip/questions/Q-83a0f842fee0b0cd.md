iOS 26 / UIKit

The ordinary button is disabled after its shortcut is created. Someone invokes the retained shortcut anyway. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -31,9 +31,9 @@
     required init(coder: NSCoder) { fatalError("Programmatic fixture") }
 
     @discardableResult
     public func select(_ rate: Float) -> Bool {
-        guard controlsEnabled, Self.rates.contains(rate) else { return false }
+        guard Self.rates.contains(rate) else { return false }
         guard rate != selectedRate else { return true }
         selectedRate = rate
         render()
         onChange?(rate)
```
