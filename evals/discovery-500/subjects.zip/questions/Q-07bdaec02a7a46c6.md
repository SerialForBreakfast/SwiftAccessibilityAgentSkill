iOS 26 / UIKit

Restoring focus can synchronously open the next panel before the first completion unwinds. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -57,9 +57,9 @@
     }
 
     @discardableResult
     func dismiss() -> Bool {
-        guard state == .open else { return false }
+        guard state == .open, canDismiss else { return false }
         state = .closing
         let token = generation
         performDismissal { [weak self] in
             guard let self, self.state == .closing, self.generation == token else { return }
```
