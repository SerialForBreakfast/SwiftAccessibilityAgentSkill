tvOS 26 / SwiftUI

Before changing this feature, what working behavior is most at risk? Compare a narrowly scoped approach with a tempting alternative that would break that behavior. Give a concrete before/after check.

Background from the original feature request (answer the question above):
tvOS, SwiftUI. Product wants titles readable from a couch. A long German title in our tvOS SwiftUI detail header crowds out Play and Details. What would you change on a 26.0 deployment target, and what would you condition on a newer SDK?
