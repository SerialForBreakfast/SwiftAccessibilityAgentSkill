tvOS 26 / SwiftUI

What should the app do here, and what should remain unchanged? Give a design answer rather than a patch.

Background from the original feature request (answer the question above):
I am using SwiftUI on tvOS 26 deployment target; available validation anchor tvOS 26.5.

A new accessibility example compiles on my machine and its extracted state model passes unit tests. Can I say the control has the right spoken output and rotor behavior? Give a useful validation plan using compiler checks and unit tests only, preserving exact failures and recording the actual SDK, deployment target and runtime separately.

This is a design/debugging question; no existing project or omitted source files are available. If code is useful, supply a self-contained minimal example and state material assumptions. Do not execute anything.
