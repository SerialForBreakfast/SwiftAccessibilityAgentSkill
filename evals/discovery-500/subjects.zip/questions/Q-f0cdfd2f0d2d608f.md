macOS 26 / AppKit

Before changing this feature, what working behavior is most at risk? Compare a narrowly scoped approach with a tempting alternative that would break that behavior. Give a concrete before/after check.

Background from the original feature request (answer the question above):
Our AppKit invoice list reuses an NSStackView row containing a title, Open button and Save button. Implement a programmatic row that can be configured repeatedly with a new title, complete localized control names and callbacks. Keep both buttons independently usable, and offer Save as an optional accessibility action on Open. Disabled Save must not dispatch. What would you implement, and what can unit tests establish?
