tvOS 26 / SwiftUI

What focused unit check would tell us this works, rather than merely compiling? Give setup, triggering path, expected result, and a defect this check would actually reject. If a part is outside unit scope, separate it.

Background from the original feature request (answer the question above):
tvOS, SwiftUI. Product wants titles readable from a couch. A long German title in our tvOS SwiftUI detail header crowds out Play and Details. What would you change on a 26.0 deployment target, and what would you condition on a newer SDK?
