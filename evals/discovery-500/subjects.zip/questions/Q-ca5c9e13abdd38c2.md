macOS 26 / SwiftUI

A text field changes through dictation while validation runs. Its inline instructions must belong to the current text. What should own each piece of state, and what should the developer preserve when the screen updates? Give a bounded implementation plan; call out anything the description does not establish.
