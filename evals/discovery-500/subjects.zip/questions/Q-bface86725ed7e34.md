iOS 26 / UIKit

What should the app do here, and what should remain unchanged? Give a design answer rather than a patch.

Background from the original feature request (answer the question above):
I'm building reusable UIKit cards for invoices, supporting iOS 26 and later. Each card shows a decorative star, an invoice title, and separate Open and Save buttons. Every card has the same visible button titles. The same card instance can be configured for another invoice without being removed. Can you show the Swift configuration and unit tests so someone can tell which invoice each button acts on, while both buttons still work normally? Our callers can supply localized strings and the two operation handlers. Focus on configuration and behavior, not layout. Explain what the unit tests establish.
