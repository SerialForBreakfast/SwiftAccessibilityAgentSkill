tvOS 26 / SwiftUI

What should the app do here, and what should remain unchanged? Give a design answer rather than a patch.

Background from the original feature request (answer the question above):
tvOS, SwiftUI. Product wants titles readable from a couch. A long German title in our tvOS SwiftUI detail header crowds out Play and Details. What would you change on a 26.0 deployment target, and what would you condition on a newer SDK?
