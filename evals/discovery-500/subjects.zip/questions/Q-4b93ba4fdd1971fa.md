macOS 26 / SwiftUI

A SwiftUI wrapper hosts an editable native search field and a Clear button. Rebuilding the surrounding view updates Clear's target. Design a regression test for this interaction. Give a realistic sequence, expected intermediate and final results, and a change that would make the test fail for the right reason. Separate what units prove from what they cannot observe.
