iOS 26 / UIKit

Restoring focus can synchronously open the next panel before the first completion unwinds. Does this version meet the requirement? Trace the actual path. Leave it alone if it works; otherwise give the smallest integrated correction.

ModalUIKit.swift:
```swift
import UIKit

@MainActor
final class RestoringPanel: UIView {
    enum State: Equatable { case closed, open, closing }
    let heading = UILabel()
    let primary = UIButton(type: .system)
    let close = UIButton(type: .system)
    private(set) var state: State = .closed
    var canDismiss = true
    var onPrimary: () -> Void = {}
    var performDismissal: (@escaping @MainActor () -> Void) -> Void = { completion in completion() }
    var post: (UIAccessibility.Notification, Any?) -> Void = { UIAccessibility.post(notification: $0, argument: $1) }
    weak var returnTarget: UIView?
    private weak var background: UIView?
    private var priorHidden = false
    private var generation = 0

    override init(frame: CGRect) {
        super.init(frame: frame)
        [heading, primary, close].forEach(addSubview)
        isAccessibilityElement = false
        isHidden = true
        accessibilityElementsHidden = true
        primary.addAction(UIAction { [weak self] _ in
            guard let self, self.state == .open, self.primary.isEnabled else { return }
            self.onPrimary()
        }, for: .touchUpInside)
        close.addAction(UIAction { [weak self] _ in _ = self?.dismiss() }, for: .touchUpInside)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    @discardableResult
    func open(background: UIView, target: UIView?, title: String, primaryTitle: String, closeTitle: String) -> Bool {

        guard state == .closed, background !== self,
              !isDescendant(of: background), !background.isDescendant(of: self) else { return false }
        generation += 1
        self.background = background
        priorHidden = background.accessibilityElementsHidden
        returnTarget = target
        background.accessibilityElementsHidden = true
        heading.text = title
        heading.isAccessibilityElement = true
        heading.accessibilityTraits.insert(.header)
        primary.setTitle(primaryTitle, for: .normal)
        close.setTitle(closeTitle, for: .normal)
        primary.isAccessibilityElement = true
        close.isAccessibilityElement = true
        accessibilityElements = [heading, primary, close]
        isHidden = false
        accessibilityElementsHidden = false
        accessibilityViewIsModal = true
        state = .open
        return true
    }

    @discardableResult
    func dismiss() -> Bool {
        guard state == .open else { return false }
        state = .closing
        let token = generation
        performDismissal { [weak self] in
            guard let self, self.state == .closing, self.generation == token else { return }
            self.finish(notify: true)
        }
        return true
    }

    private func finish(notify: Bool) {
        let target = returnTarget.flatMap { candidate -> UIView? in
            guard let background, !priorHidden, candidate.isDescendant(of: background) else { return nil }
            return candidate
        }
        background?.accessibilityElementsHidden = priorHidden
        background = nil
        returnTarget = nil
        state = .closed
        isHidden = true
        accessibilityElementsHidden = true
        accessibilityViewIsModal = false
        onPrimary = {}
        if notify { post(.screenChanged, target) }
    }

    func tearDown() {
        guard state != .closed else { return }
        generation += 1
        finish(notify: false)
    }

    override func accessibilityPerformEscape() -> Bool { dismiss() }
}
```
