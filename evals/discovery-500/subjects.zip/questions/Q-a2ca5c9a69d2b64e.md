macOS 26 / AppKit

What would you ship for this request? Follow the interaction from the existing control to its effect; provide integrated Swift where needed, or explain why the existing implementation is sufficient.

Background from the original feature request (answer the question above):
macOS, AppKit. Two document windows can each open their own inspector. Closing the inspector in one window sometimes sends keyboard input to the other document. How would you structure ownership of the return destination?
