iOS 26 / UIKit

A card offers Archive and Remove shortcuts. Both names appear correct but we need to know which operation runs. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -89,8 +89,7 @@
     }
     private func perform(token: Int, id: String, operation: MessageOperation) -> Bool {
         guard token == revision, active else { return false }
         onAction(id, operation)
-        onAction(id, operation)
         return true
     }
 }
```
