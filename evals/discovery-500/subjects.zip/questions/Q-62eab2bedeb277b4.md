macOS 26 / SwiftUI

A user cancels a previous reload while the new reload is still showing progress. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -92,9 +92,9 @@
         }
     }
 
     private func cancel(ticket: Int) {
-        guard active == ticket else { return }
+
         cancel()
     }
 
     func cancel() {
```
