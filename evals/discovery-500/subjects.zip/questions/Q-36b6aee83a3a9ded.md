iOS 26 / SwiftUI

A filtered subtitle menu does not contain the current track. A restored preference then requests a deleted option. Design a regression test for this interaction. Give a realistic sequence, expected intermediate and final results, and a change that would make the test fail for the right reason. Separate what units prove from what they cannot observe.
