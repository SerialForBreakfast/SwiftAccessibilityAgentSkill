macOS 26 / SwiftUI

Before changing this feature, what working behavior is most at risk? Compare a narrowly scoped approach with a tempting alternative that would break that behavior. Give a concrete before/after check.

Background from the original feature request (answer the question above):
macOS, SwiftUI. The sidebar hosts an AppKit search field in SwiftUI. Both the wrapper and the editable field announce Search and people encounter two stops. The AppKit field handles selection and insertion. What would you change, and what should stay editable?
