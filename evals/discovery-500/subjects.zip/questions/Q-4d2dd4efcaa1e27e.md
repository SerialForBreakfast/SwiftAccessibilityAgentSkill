macOS 26 / AppKit

Before changing this feature, what working behavior is most at risk? Compare a narrowly scoped approach with a tempting alternative that would break that behavior. Give a concrete before/after check.

Background from the original feature request (answer the question above):
We use a programmatic AppKit NSOutlineView for a nested library. Entries have stable IDs, titles and child arrays. Show Name and Kind columns. Updates can rename, reorder or remove entries; keep surviving item identity, expansion and visible selection where possible. Reject duplicate IDs anywhere in an update without partly changing the current tree. Removed entries should not continue supplying stale child data. Implement the data source for macOS 26 and unit tests; do not drive the UI.
