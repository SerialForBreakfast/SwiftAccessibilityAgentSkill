macOS 26 / AppKit

An audio menu has two Spanish tracks, one commentary and one described. Product wants a badge on just the described one. Does this version meet the requirement? Trace the actual path. Leave it alone if it works; otherwise give the smallest integrated correction.

MediaMetadata.swift:
```swift
import AVFoundation

public struct MediaOptionEvidence {
    public let name: String
    public let language: String?
    public let describesVideo: Bool
    public let forcedOnly: Bool
    public let selected: Bool
}

public enum GroupEvidence {
    case unavailable
    case absent
    case loaded([MediaOptionEvidence])
}

@MainActor
public enum MediaMetadata {

    public static func group(_ characteristic: AVMediaCharacteristic,
                             item: AVPlayerItem?) async throws -> GroupEvidence {
        guard let item else { return .unavailable }
        guard let group = try await item.asset.loadMediaSelectionGroup(for: characteristic) else {
            return .absent
        }
        let selected = item.currentMediaSelection.selectedMediaOption(in: group)
        return .loaded(group.options.map { option in
            MediaOptionEvidence(name: option.displayName,
                language: option.locale?.language.languageCode?.identifier,
                describesVideo: option.hasMediaCharacteristic(.describesVideoForAccessibility),
                forcedOnly: option.hasMediaCharacteristic(.containsOnlyForcedSubtitles),
                selected: option == selected)
        })
    }

    public static func duration(item: AVPlayerItem) async throws -> CMTime {
        try await item.asset.load(.duration)
    }
}
```
