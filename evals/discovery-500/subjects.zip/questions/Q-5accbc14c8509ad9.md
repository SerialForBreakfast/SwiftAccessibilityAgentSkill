tvOS 26 / UIKit

A show-card theme accepts only opaque palettes. A designer submits a translucent mid-gray highlight. What should own each piece of state, and what should the developer preserve when the screen updates? Give a bounded implementation plan; call out anything the description does not establish.
