macOS 26 / AppKit

Before changing this feature, what working behavior is most at risk? Compare a narrowly scoped approach with a tempting alternative that would break that behavior. Give a concrete before/after check.

Background from the original feature request (answer the question above):
macOS, AppKit. Two document windows can each open their own inspector. Closing the inspector in one window sometimes sends keyboard input to the other document. How would you structure ownership of the return destination?
