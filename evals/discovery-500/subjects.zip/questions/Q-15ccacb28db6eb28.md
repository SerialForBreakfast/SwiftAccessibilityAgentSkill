iOS 26 / UIKit

A document contains an emoji before a search hit, and navigation selects the neighboring substring. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -19,9 +19,9 @@
                 ? current.map { $0 + 1 } ?? 0
                 : current.map { $0 - 1 } ?? self.matches.count - 1
             guard self.matches.indices.contains(index) else { return nil }
             let match = self.matches[index]
-            guard let start = self.textView.position(from: self.textView.beginningOfDocument, offset: match.location),
+            guard let start = self.textView.position(from: self.textView.beginningOfDocument, offset: match.location + 1),
                   let end = self.textView.position(from: self.textView.beginningOfDocument, offset: match.location + match.length),
                   let range = self.textView.textRange(from: start, to: end) else { return nil }
             return UIAccessibilityCustomRotorItemResult(targetElement: self.textView, targetRange: range)
         }]
```
