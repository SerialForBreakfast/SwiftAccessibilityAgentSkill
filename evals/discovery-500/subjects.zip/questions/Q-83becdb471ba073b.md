iOS 26 / SwiftUI

An animated episode card becomes static under Reduce Motion. Play and the supplementary play-from-start command must still do different things. What should own each piece of state, and what should the developer preserve when the screen updates? Give a bounded implementation plan; call out anything the description does not establish.
