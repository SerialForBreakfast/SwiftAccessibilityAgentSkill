tvOS 26 / SwiftUI

The TV picker offers subtitle choices; one asset permits Off and another does not. A user changes between them without leaving the player. Design a regression test for this interaction. Give a realistic sequence, expected intermediate and final results, and a change that would make the test fail for the right reason. Separate what units prove from what they cannot observe.
