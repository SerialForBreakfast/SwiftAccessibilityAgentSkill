tvOS 26 / SwiftUI

A German title wraps over the Play and Details controls. Both remote actions should stay reachable and retain different destinations. Design a regression test for this interaction. Give a realistic sequence, expected intermediate and final results, and a change that would make the test fail for the right reason. Separate what units prove from what they cannot observe.
