iOS 26 / UIKit

The same price label is configured repeatedly at successively larger and smaller text sizes with a brand font. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -31,9 +31,9 @@
             label.numberOfLines = 0
             label.lineBreakMode = .byWordWrapping
             label.adjustsFontSizeToFitWidth = false
             label.adjustsFontForContentSizeCategory = true
-            label.font = .preferredFont(forTextStyle: .body, compatibleWith: label.traitCollection)
+            label.font = .systemFont(ofSize: 17)
             label.textColor = .label
             label.isAccessibilityElement = false
         }
         isAccessibilityElement = true
```
