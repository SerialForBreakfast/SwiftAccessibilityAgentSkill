macOS 26 / AppKit

A sidebar refresh removes one folder and contains the same ID in two new branches. A client still holds the old folder object. What should own each piece of state, and what should the developer preserve when the screen updates? Give a bounded implementation plan; call out anything the description does not establish.
