iOS 26 / UIKit

The palette tool accepts only opaque foreground/background pairs. A designer supplies a translucent overlay. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -45,9 +45,9 @@
 @MainActor
 enum ConfiguredContrast {
     static func resolve(_ color: UIColor, traits: UITraitCollection) throws -> OpaqueSRGB {
         let original = color.resolvedColor(with: traits).cgColor
-        guard original.alpha == 1 else { throw ContrastError.translucent }
+
         guard original.colorSpace?.model != .pattern,
               let space = CGColorSpace(name: CGColorSpace.sRGB),
               let converted = original.converted(to: space, intent: .relativeColorimetric, options: nil),
               let values = converted.components, values.count == 4 else {
```
