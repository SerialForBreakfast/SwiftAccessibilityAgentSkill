macOS 26 / SwiftUI

The menu highlights French but the same video keeps showing English captions. The player itself must not be replaced. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -34,9 +34,9 @@
               let selected = item.currentMediaSelection.selectedMediaOption(in: group) else { return nil }
         return choices.first { $0.option == selected }?.id
     }
     var selection: Binding<String?> {
-        Binding(get: { self.selectedID }, set: { _ = self.choose($0) })
+        Binding(get: { self.selectedID }, set: { _ in })
     }
     var status: String {
         switch phase {
         case .idle: return "Options not loaded"
```
