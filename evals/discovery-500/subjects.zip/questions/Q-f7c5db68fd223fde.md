iOS 26 / UIKit

A support screen says Ready whenever the buffer is full, including after the item failed. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -39,9 +39,9 @@
         self.seekable = seekable
         self.loaded = loaded
         self.bufferEmpty = bufferEmpty
         self.bufferFull = bufferFull
-        self.likelyToKeepUp = bufferFull
+        self.likelyToKeepUp = likelyToKeepUp
         self.requestedRate = requestedRate
         self.timeControlStatus = timeControlStatus
         self.waitingReason = waitingReason
     }
```
