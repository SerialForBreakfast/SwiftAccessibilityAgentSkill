iOS 26 / SwiftUI

A font preview lets someone choose a size without changing their device. Other labels still follow the live size setting. Design a regression test for this interaction. Give a realistic sequence, expected intermediate and final results, and a change that would make the test fail for the right reason. Separate what units prove from what they cannot observe.
