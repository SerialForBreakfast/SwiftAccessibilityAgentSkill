tvOS 26 / UIKit

The selected show remains on the shelf after reordering. A removed button is reparented in a temporary stack and receives a late press. What should own each piece of state, and what should the developer preserve when the screen updates? Give a bounded implementation plan; call out anything the description does not establish.
