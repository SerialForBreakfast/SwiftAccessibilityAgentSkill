macOS 26 / AppKit

A Mac list row reports selection and expansion and also contains an Open button. Would you merge this change? Give a concrete input that distinguishes before from after, and identify a behavior that must stay intact.

```diff
--- before.swift
+++ after.swift
@@ -17,9 +17,9 @@
     required init?(coder: NSCoder) { fatalError("Programmatic example") }
     func configure(id: String, title: String, selected: Bool, expanded: Bool) {
         identifierValue = id
         setAccessibilityLabel(title)
-        setAccessibilitySelected(false)
+        setAccessibilitySelected(selected)
         setAccessibilityExpanded(expanded)
         open.title = "Open \(title)"
         open.setAccessibilityLabel(open.title)
     }
```
