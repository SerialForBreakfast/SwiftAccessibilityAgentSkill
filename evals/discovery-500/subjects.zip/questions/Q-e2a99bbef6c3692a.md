macOS 26 / AppKit

You are reviewing a proposed implementation of the feature below. Set acceptance criteria that would accept two different correct implementations, reject a plausible wrong one, and distinguish a grader/setup problem from a product defect.

Background from the original feature request (answer the question above):
I'm reviewing a AppKit change for macOS 26.0. Can the table row describe its role and selection without swallowing its actionable children?

Supplied implementation:
```swift
import AppKit

@MainActor
final class DesktopRow: NSView {
    let open = NSButton(title: "Open", target: nil, action: nil)
    private(set) var identifierValue = ""
    var choose: (String) -> Void = { _ in }
    override init(frame: NSRect) {
        super.init(frame: frame)
        addSubview(open)
        setAccessibilityElement(true)
        setAccessibilityRole(.row)
        setAccessibilityChildren([open])
        open.target = self
        open.action = #selector(activate)
    }
    required init?(coder: NSCoder) { fatalError("Programmatic example") }
    func configure(id: String, title: String, selected: Bool, expanded: Bool) {
        identifierValue = id
        setAccessibilityLabel(title)
        setAccessibilitySelected(selected)
        setAccessibilityExpanded(expanded)
        open.title = "Open \(title)"
        open.setAccessibilityLabel(open.title)
    }
    @objc func activate() { guard open.isEnabled else { return }; choose(identifierValue) }
}
```
